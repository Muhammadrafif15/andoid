package com.example.myfavoritemanhwa

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myfavoritemanhwa.databinding.ItemRowManhwaBinding

class ListManhwaAdapter(private val listManhwa :ArrayList<Data>) :
    RecyclerView.Adapter<ListManhwaAdapter.ListViewHolder>() {


    class ListViewHolder(var binding: ItemRowManhwaBinding) : RecyclerView.ViewHolder(binding.root) {
//        init {
//            itemView.setOnClickListener{
//                listener.onItemClick(adapterPosition)
//            }
//        }
    }

//    private lateinit var clickedAdapter : onItemClickListener
//
//
//    interface onItemClickListener{
//        fun onItemClick(data: DetailMahnwa)
//    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListManhwaAdapter.ListViewHolder {
        val binding = ItemRowManhwaBinding.inflate(LayoutInflater.from(viewGroup.context),viewGroup,false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListManhwaAdapter.ListViewHolder, position: Int) {
        val (name, genre, photo) = listManhwa[position]
        holder.binding.imgItemPhoto.setImageResource(photo)
        holder.binding.tvItemName.text = name
        holder.binding.tvItemGenre.text = genre




        holder.itemView.setOnClickListener {
            val intentDetail = Intent(holder.itemView.context, DetailActivity::class.java)
            intentDetail.putExtra(DetailActivity.EXTRA_DETAIL, listManhwa[position])
            holder.itemView.context.startActivity(intentDetail)
        }
    }
    override fun getItemCount(): Int = listManhwa.size
//    fun setOnItemClickListener(clickedAdapter: onItemClickListener) {
//        this.clickedAdapter = clickedAdapter
//    }


}