package com.example.myfavoritemanhwa

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import com.example.myfavoritemanhwa.databinding.ActivityDetailBinding
import org.w3c.dom.Text

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    companion object{
        const val EXTRA_DETAIL = "extra_detail"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val manhwa = intent.getParcelableExtra<DetailMahnwa>(EXTRA_DETAIL,DetailMahnwa::class.java)

        if (manhwa != null) {
            binding.tvCoverName.setText(manhwa.name)
            binding.imgCover.setImageResource(manhwa.photo)
            binding.tvCoverSinopsis.setText(manhwa.sinopsis)
            binding.tvGenre.setText(manhwa.genre)
            binding.tvStatus.setText(manhwa.status)
            binding.tvRelease.setText(manhwa.release)

        }


        }




}