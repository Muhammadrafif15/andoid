package com.example.myfavoritemanhwa

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DetailMahnwa(
    val photo: Int,
    val name: String,
    val release: String,
    val genre: String?,
    val status: String?,
    val sinopsis: String,

    ) : Parcelable

