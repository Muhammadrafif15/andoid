package com.example.myfavoritemanhwa

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View.OnClickListener
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myfavoritemanhwa.DetailActivity.Companion.EXTRA_DETAIL
import com.example.myfavoritemanhwa.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private val list= ArrayList<Data>()
    private val detailList = ArrayList<DetailMahnwa>()
    private lateinit var binding: ActivityMainBinding

//    private fun selected( detailMahnwa: DetailMahnwa){
//
//        val intent = Intent(this, detailMahnwa::class.java)
//        intent.putExtra(EXTRA_DETAIL,detailMahnwa)
//        startActivity(intent)
//
//    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvManhwa.setHasFixedSize(true)

        list.addAll(getLishManhwa())
        detailList.addAll(getLishDetail())
        showRecyclelist()
        getLishDetail()


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.about, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.about_menu -> {

                val moveAboutMe = Intent(this@MainActivity, AboutMe::class.java)
                Toast.makeText(this,"About Selected",Toast.LENGTH_SHORT).show()
                startActivities(arrayOf(moveAboutMe))
            }
        }
            return super.onOptionsItemSelected(item)
    }

    private fun getLishDetail(): ArrayList<DetailMahnwa> {
        val coverImg = resources.obtainTypedArray(R.array.data_photo)
        val coverName = resources.getStringArray(R.array.data_name)
        val coverSinopsis = resources.getStringArray(R.array.data_sinopsis)
        val coverGenre = resources.getStringArray(R.array.data_genre)
        val coverRelease = resources.getStringArray(R.array.data_release)
        val coverStatus = resources.getStringArray(R.array.data_status)
        val detailManwa = ArrayList<DetailMahnwa>()
        for (u in coverName.indices){
            val cover = DetailMahnwa(coverImg.getResourceId(u,-1),coverName[u],coverSinopsis[u],coverGenre[u],coverRelease[u],coverStatus[u],)
            detailManwa.add(cover)
        }
        return detailManwa
    }



    private fun getLishManhwa():ArrayList<Data>{
        val dataName = resources.getStringArray(R.array.data_name)
        val dataGenre = resources.getStringArray(R.array.data_genre)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val lishManhwa = ArrayList<Data>()
        for (i in dataName.indices){
            val manhwa =Data(
                dataName[i],
                dataGenre[i],
                dataPhoto.getResourceId(i,-1)
            )
            lishManhwa.add(manhwa)
     }
//        var adapter = ListManhwaAdapter(lishManhwa)
//        binding.rvManhwa.adapter = adapter
//        adapter.setOnItemClickListener(object : ListManhwaAdapter.onItemClickListener{
//            override fun onItemClick(data: DetailMahnwa) {
//                val intent = Intent(this@MainActivity,DetailActivity::class.java)
//                intent.putExtra("name",lishManhwa[position].name)
//                intent.putExtra("photo",lishManhwa[position].photo)
//                intent.putExtra("genre",lishManhwa[position].genre)
//                startActivity(intent)
//            }
//        })

        return lishManhwa
    }
    private fun showRecyclelist(){
        binding.rvManhwa.layoutManager = LinearLayoutManager(this)
        val listManhwaAdapter = ListManhwaAdapter(list)
        binding.rvManhwa.adapter = listManhwaAdapter

//        listManhwaAdapter.setOnItemClickListener(object : ListManhwaAdapter.onItemClickListener{
//            override fun onItemClick(data: DetailMahnwa) {
//                selected(data)
//            }
//        })
//        val intent = Intent(this, DetailMahnwa::class.java)
//        intent.putExtra(EXTRA_DETAIL,DetailMahnwa)
//        startActivity(intent)


    }





}